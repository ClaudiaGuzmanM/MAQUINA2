package main

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"sync"
	"time"

	pb "github.com/EdwardFlowersGg/Lab4_INF-343/proto"
	"google.golang.org/grpc"
)

type Mercenario struct {
	ID            int32
	Nombre        string
	Piso          int32
	Alive         bool
	Ronda         int
	aciertosRonda int
}

var (
	mutex sync.Mutex
)

func QuieroJugar(client pb.KFserviceClient, jugador *Mercenario) string {
	var option string
	showMenu(jugador.Piso)
	fmt.Print("Selecciona una opción: ")
	fmt.Scanln(&option)
	switch option {
	case "1":
		playerPlayGame(client, jugador)
		time.Sleep(1 * time.Second) // Simula un pequeño retraso entre turnos
	case "2":
		response, err := client.SolicitarMontoDineroMercenarioDirector(context.Background(), &pb.MontoDineroMercenarioDirectorRequest{
			ID:     jugador.ID,
			Nombre: jugador.Nombre,
		})
		if err != nil {
			log.Printf("Error al solicitar el monto de dinero del jugador %s: %v", jugador.Nombre, err)
		} else {
			fmt.Printf("El Poso actual es de  %f\n", response.Amount)
		}
	case "3":
		fmt.Println("Saliendo del juego...")
	default:
		fmt.Println("Opción no válida. Por favor, ingrese 1, 2 o 3.")
	}

	// Desbloquear el mutex al final del turno del jugador
	time.Sleep(1 * time.Second) // Simula un pequeño retraso entre turnos

	return option
}

func QuieroEntrarPiso(client pb.KFserviceClient, mercenario *Mercenario) {
	for {
		response, err := client.SolicitarEntrarPiso(context.Background(), &pb.EntrarPisoRequest{
			ID:     mercenario.ID,
			Nombre: mercenario.Nombre,
			Piso:   mercenario.Piso,
			Estado: int32(mercenario.Ronda),
		})
		if err != nil {
			//log.Printf("Error al registrar al mercenario %s: %v", mercenario.Nombre, err)
			time.Sleep(5 * time.Second)
			continue
		}

		if response.Success {
			//log.Printf("El mercenario %s ha entrado al piso %d.", mercenario.Nombre, mercenario.Piso)
			break
		} else {
			//log.Printf("No se puede entrar al  piso %d,  %s. Reintentando en 5 segundos...", mercenario.Piso, mercenario.Nombre)
			time.Sleep(5 * time.Second)
		}
	}
}

func playerRoutine(client pb.KFserviceClient, jugador *Mercenario) {
	for jugador.Alive {

		if jugador.Ronda == 6 {
			Resultado := jugador.aciertosRonda >= 2
			for {
				response, err := client.SolicitarFinal(context.Background(), &pb.FinalRequest{
					ID:      jugador.ID,
					Nombre:  jugador.Nombre,
					Success: Resultado,
				})
				if err != nil {
					fmt.Printf("Error al solicitar el final: %v\n", err)
					time.Sleep(5 * time.Second)
					continue
				}
				if response.Success {
					break
				} else {
					fmt.Println("Esperando a que el director finalice la partida...")
					time.Sleep(5 * time.Second)
				}
			}
			fmt.Println("Fin de la partida")
			if Resultado {
				fmt.Println("Felicidades, has ganado")
			} else {
				fmt.Println("Lo siento, has perdido")
			}
			return
		}
		QuieroEntrarPiso(client, jugador)

		for {
			response, err := client.SolicitarResultado(context.Background(), &pb.JugarRequest{
				Success: true,
			})
			if err != nil {
				log.Printf("Error al solicitar resultado para el jugador %s: %v", jugador.Nombre, err)
				time.Sleep(5 * time.Second)
				continue
			}

			if response.Success {
				break
			} else {
				fmt.Println("Esperando a que el director comience la partida...")
				time.Sleep(5 * time.Second)
			}
		}
		mutex.Lock()
		for {
			option := QuieroJugar(client, jugador)
			if option == "1" {
				break
			}
		}
		mutex.Unlock()

	}
}

func playerPlayGame(client pb.KFserviceClient, jugador *Mercenario) {
	if jugador.Piso > 3 {
		return
	}

	var move int32
	switch jugador.Piso {
	case 1:
		fmt.Println("Elige tu arma: (1) Escopeta, (2) Rifle automático, (3) Puños eléctricos")
		fmt.Scanln(&move)
	case 2:
		fmt.Println("Elige un pasillo: (1) A, (2) B")
		fmt.Scanln(&move)
	case 3:
		fmt.Println("Elige un número del 1 al 15")
		fmt.Scanln(&move)
	}

	response, err := client.SolicitarMovimiento(context.Background(), &pb.MovimientoRequest{
		ID:     jugador.ID,
		Nombre: jugador.Nombre,
		Piso:   jugador.Piso,
		Mov:    move,
	})
	if err != nil {
		log.Printf("Error en la jugada del jugador %s: %v", jugador.Nombre, err)
		return
	}
	if jugador.Piso != 3 {
		if response.Success {
			jugador.Piso++
		} else {
			jugador.Alive = false
			fmt.Printf("El mercenario %s ha muerto en el piso %d\n", jugador.Nombre, jugador.Piso)
		}
	} else {
		if response.Success {
			jugador.aciertosRonda++
		}
		fmt.Printf("Fin de ronda: %d\n", jugador.Ronda)
		jugador.Ronda++
	}
}

func botRoutine(client pb.KFserviceClient, bot *Mercenario) {
	for bot.Alive {
		// Esperar a que el jugador termine su turno
		QuieroEntrarPiso(client, bot)

		if bot.Ronda == 6 {
			Resultado := bot.aciertosRonda >= 2
			for {
				response, err := client.SolicitarFinal(context.Background(), &pb.FinalRequest{
					ID:      bot.ID,
					Nombre:  bot.Nombre,
					Success: Resultado,
				})
				if err != nil {
					//fmt.Printf("Error al solicitar el final: %v\n", err)
					time.Sleep(5 * time.Second)
					continue
				}
				if response.Success {
					break
				} else {
					//fmt.Println("Esperando a que el director finalice la partida...")
					time.Sleep(5 * time.Second)
				}
			}
			//fmt.Println("Fin de la partida")
			if Resultado {
				//fmt.Println("Felicidades, has ganado")
			} else {
				//fmt.Println("Lo siento, has perdido")
			}
			return
		}

		for {
			response, err := client.SolicitarResultado(context.Background(), &pb.JugarRequest{
				Success: true,
			})
			if err != nil {
				log.Printf("Error al solicitar resultado para el bot %s: %v", bot.Nombre, err)
				time.Sleep(5 * time.Second)
				continue
			}

			if response.Success {
				break
			} else {
				time.Sleep(5 * time.Second)
			}
		}
		mutex.Lock()
		botPlayGame(client, bot)
		time.Sleep(time.Duration(rand.Intn(3)+1) * time.Second)
		mutex.Unlock()
	}
}

func botPlayGame(client pb.KFserviceClient, bot *Mercenario) {
	if bot.Piso > 3 {
		return
	}

	var move int32
	switch bot.Piso {
	case 1:
		move = rand.Int31n(3) + 1
	case 2:
		move = rand.Int31n(2) + 1
	case 3:
		move = rand.Int31n(15) + 1
	}

	response, err := client.SolicitarMovimiento(context.Background(), &pb.MovimientoRequest{
		ID:     bot.ID,
		Nombre: bot.Nombre,
		Piso:   bot.Piso,
		Mov:    move,
	})
	if err != nil {
		log.Printf("Error en la jugada del bot %s: %v", bot.Nombre, err)
		return
	}

	if bot.Piso != 3 {
		if response.Success {
			bot.Piso++
		} else {
			bot.Alive = false
			fmt.Printf("El mercenario %s ha muerto en el piso %d\n", bot.Nombre, bot.Piso)
		}
	} else {
		if response.Success {
			bot.aciertosRonda++
		}
		//fmt.Printf("Fin de ronda: %d\n", bot.Ronda)
		bot.Ronda++
	}
}

func showMenu(piso int32) {
	fmt.Printf("Piso actual: %d\n", piso)
	fmt.Println("Opciones:")
	fmt.Println("1. Jugar")
	fmt.Println("2. Ver Monto de Dinero")
	fmt.Println("3. Salir del juego")
	fmt.Print("Ingrese su opción: ")
}

func main() {
	rand.Seed(time.Now().UnixNano())

	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
	if err != nil {
		log.Fatalf("Error al conectar: %v", err)
	}
	defer conn.Close()
	client := pb.NewKFserviceClient(conn)

	jugador := Mercenario{
		ID:            1,
		Nombre:        "jugador1",
		Piso:          1,
		Alive:         true,
		Ronda:         1,
		aciertosRonda: 0,
	}

	var bots []Mercenario
	for i := int32(2); i <= 8; i++ {
		bot := Mercenario{
			ID:            i,
			Nombre:        fmt.Sprintf("bot%d", i),
			Piso:          1,
			Alive:         true,
			Ronda:         1,
			aciertosRonda: 0,
		}
		bots = append(bots, bot)
	}

	var wg sync.WaitGroup

	wg.Add(1)
	go func() {
		defer wg.Done()
		playerRoutine(client, &jugador)
	}()

	for i := range bots {
		wg.Add(1)
		go func(bot *Mercenario) {
			defer wg.Done()
			botRoutine(client, bot)
		}(&bots[i])
	}

	wg.Wait()
	fmt.Println("El juego ha terminado.")
}
